<?php
/**
 * 海奇会员模块定义
 *
 * @author sxm0202
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class Haiqihuiyuan_customerModule extends WeModule {



}