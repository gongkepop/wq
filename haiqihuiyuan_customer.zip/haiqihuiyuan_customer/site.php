<?php
/**
 * 海奇会员模块微站定义
 *
 * @author sxm0202
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class Haiqihuiyuan_customerModuleSite extends WeModuleSite {

	public function doWebUserList() {

		//这个操作被定义用来呈现 管理中心导航菜单
	}
	public function doWebAddUser() {
        global $_W;
        include  $this->template(userList);
		//这个操作被定义用来呈现 管理中心导航菜单
	}

	public function doWebSyncUser(){

    }





}